function Test2() {
    return (
      <div>
        Test {1+1}
      </div>
    );
  }
  
  export default Test2;
  
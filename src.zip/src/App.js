//====================================================================================================================================================================================
//                                                                            LIST OF USERNAMES AND PASSWORDS
//                                                                              USER #1: Username: user1
//                                                                                       Password: bg3
//
//                                                                              USER #1: Username: user2
//                                                                                       Password: bg4
//====================================================================================================================================================================================


//=============================================================================== IMPORTING FIRESTORE FUNCTIONS =====================================================================
import React, { useState, useEffect } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore'; 
import LoginPage from './pages/loginpage';
//====================================================================================================================================================================================


//=============================================================================== IMPORTING OTHER FUNCTIONS ==========================================================================
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';
import Article from './pages/Article';
import EditArticle from './pages/EditArticle';
//====================================================================================================================================================================================


//=============================================================================== FIREBASE CONFIG ====================================================================================
const firebaseConfig = {
  apiKey: "AIzaSyB_Uec0EICbuOWuFLa7ijIhbaLOERiCMnU",
  authDomain: "fir-16aef.firebaseapp.com",
  projectId: "fir-16aef",
  storageBucket: "fir-16aef.appspot.com",
  messagingSenderId: "633910837388",
  appId: "1:633910837388:web:c781c832b0586ecb5ffba9",
  measurementId: "G-ZZ8MEKNWDY"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app); 
//====================================================================================================================================================================================


//=============================================================================== MAIN APPLICATION ===================================================================================
function App() {
  const [articles, setArticles] = useState([]);

  useEffect(() => {
    const fetchArticles = async () => {
      try {
        const articlesCollection = await getDocs(collection(db, 'articles'));
        const articlesData = articlesCollection.docs.map(doc => doc.data());
        setArticles(articlesData);
      } catch (error) {
        console.error('Error fetching articles from Firebase:', error);
      }
    };

    fetchArticles();
  }, [db]);

  return (
    <div className="App">
      <BrowserRouter>
        <nav>
          <h1>Joaquin's Collection of Articles</h1>
          <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route path="/home" element={<Home articles={articles} />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact/:param" element={<Contact />} />
            <Route path="/articles/:urlId" element={<Article articles={articles} />} />
            <Route path="/edit/:urlId" element={<EditArticle />} />
          </Routes>

        </nav>
      </BrowserRouter>
    </div>
  );
}

export default App;
//====================================================================================================================================================================================

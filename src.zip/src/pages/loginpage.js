import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getDoc, doc, getFirestore } from 'firebase/firestore';

const LoginPage = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ username: '', password: '' });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const db = getFirestore(); 
    try {
      const userDocRef = doc(db, 'users', formData.username);
      const userDocSnapshot = await getDoc(userDocRef);

      if (userDocSnapshot.exists()) {
        const userData = userDocSnapshot.data();

        if (userData.password === formData.password) {
          console.log('Login successful');
          navigate('/home');
        } else {
          setError('Invalid username or password');
        }
      } else {
        setError('User not found');
      }
    } catch (error) {
      setError('An error occurred during login');
      console.error('Login error:', error);
    }
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Login</h2>
      {error && <p style={styles.error}>{error}</p>}
      <form onSubmit={handleSubmit} style={styles.form}>
        <label style={styles.label}>
          Username:
          <input type="text" name="username" value={formData.username} onChange={handleChange} style={styles.input} />
        </label>
        <br />
        <label style={styles.label}>
          Password:
          <input type="password" name="password" value={formData.password} onChange={handleChange} style={styles.input} />
        </label>
        <br />
        <button type="submit" style={styles.button}>Login</button>
      </form>
    </div>
  );
};

const styles = {
  container: {
    textAlign: 'center',
    marginTop: '50px',
  },
  title: {
    fontSize: '24px',
    marginBottom: '20px',
    color: '#333', 
  },
  error: {
    color: 'red',
    marginBottom: '10px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  label: {
    margin: '10px 0',
  },
  input: {
    padding: '8px',
    fontSize: '16px',
  },
  button: {
    backgroundColor: '#007bff',
    color: '#fff',
    padding: '10px 20px',
    fontSize: '18px',
    cursor: 'pointer',
    marginTop: '20px',
  },
};

export default LoginPage;

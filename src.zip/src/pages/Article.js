import { useNavigate, useParams } from "react-router-dom";
import { getDoc, doc } from "firebase/firestore";
import { db } from "../firebase/config";
import { useEffect, useState } from "react";

export default function Article() {
  const { urlId } = useParams();
  const navigate = useNavigate();

  const [article, setArticle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchArticle = async () => {
      try {
        const articleRef = doc(db, "articles", urlId);
        const snapshot = await getDoc(articleRef);

        if (snapshot.exists()) {
          setArticle(snapshot.data());
        } else {
          console.log("Article not found");
          setError("Article not found");
        }
      } catch (error) {
        console.error("Error fetching article:", error);
        setError("Error fetching article");
      } finally {
        setLoading(false);
      }
    };

    if (urlId) {
      fetchArticle();
    }
  }, [urlId]);

  const handleEditClick = () => {
    navigate(`/edit/${urlId}`);
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  if (!article) {
    setTimeout(() => {
      navigate("/");
    }, 2000);
  }

  return (
    <div>
      {!article && <p>No records found!</p>}
      {article && (
        <div key={article.id}>
          <h2>{article.title}</h2>
          <p>By {article.author}</p>
          <p>{article.body}</p>
          <button
            onClick={handleEditClick}
            style={{
              backgroundColor: '#3498db', /* Blue background color */
              color: 'white', /* White text color */
              padding: '8px 12px', /* Padding */
              border: 'none', /* Remove borders */
              borderRadius: '4px', /* Rounded corners */
              cursor: 'pointer', /* Pointer cursor on hover */
              fontSize: '14px', /* Set font size */
            }}
          >
            Edit
          </button>
        </div>
      )}
    </div>
  );
}
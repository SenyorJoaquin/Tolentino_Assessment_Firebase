export default function About() {
    return (
      <div>
        <h2>About</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore, quisquam. Tempora quod dolores a, at quis accusantium praesentium vitae beatae aliquam harum autem fugit! Unde repellendus est pariatur quia odit!</p>
      </div>
    )
  }
  
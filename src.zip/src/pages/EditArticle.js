// EditArticle.js

import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getDoc, doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase/config';

export default function EditArticle() {
  const { urlId } = useParams();
  const navigate = useNavigate();

  const [editedArticle, setEditedArticle] = useState({
    title: '',
    author: '',
    body: '',
  });

  useEffect(() => {
    const fetchArticle = async () => {
      try {
        const articleRef = doc(db, 'articles', urlId);
        const snapshot = await getDoc(articleRef);

        if (snapshot.exists()) {
          setEditedArticle(snapshot.data());
        } else {
          console.log('Article not found');
        }
      } catch (error) {
        console.error('Error fetching article for edit:', error);
      }
    };

    if (urlId) {
      fetchArticle();
    }
  }, [urlId]);

  const handleInputChange = (e) => {
    setEditedArticle({
      ...editedArticle,
      [e.target.name]: e.target.value,
    });
  };

  const handleSaveClick = async () => {
    try {
      const articleRef = doc(db, 'articles', urlId);
      await updateDoc(articleRef, editedArticle);
      console.log('Article updated successfully');
      navigate(`/articles/${urlId}`);
    } catch (error) {
      console.error('Error updating article:', error);
    }
  };

  return (
    <div style={{ fontSize: '16px' }}> {/* Set the desired font size */}
      <h2>Edit Article</h2>
      <div className="edit-field">
        <label style={{ fontSize: '18px' }}>Title:</label> {/* Adjust font size */}
        <input type="text" name="title" value={editedArticle.title} onChange={handleInputChange} style={{ fontSize: '16px' }} />
      </div>
      <div className="edit-field">
        <label style={{ fontSize: '18px' }}>Author:</label> {/* Adjust font size */}
        <input type="text" name="author" value={editedArticle.author} onChange={handleInputChange} style={{ fontSize: '16px' }} />
      </div>
      <div className="edit-field">
        <label style={{ fontSize: '18px' }}>Body:</label> {/* Adjust font size */}
        <textarea
          name="body"
          value={editedArticle.body}
          onChange={handleInputChange}
          rows={10}
          style={{ width: '100%', fontSize: '16px' }} // Set the width and font size as needed
        />
      </div>
      <button
        onClick={handleSaveClick}
        style={{
          backgroundColor: '#4CAF50', /* Green background color */
          color: 'white', /* White text color */
          padding: '10px 15px', /* Padding */
          border: 'none', /* Remove borders */
          borderRadius: '5px', /* Rounded corners */
          cursor: 'pointer', /* Pointer cursor on hover */
          fontSize: '16px', /* Set font size */
        }}
      >
        Save
      </button>
    </div>
  );
}